Params: ./cmzasha --learn-mm 0 data/BA000033.fna 
Build: release
Host: wingless.cs.washington.edu
----fastaFile: data/BA000033.fna
----cmFile: not-a-cm-file (global)

After scanning, learned Markov model:
0-order Markov model:
order & count-dump list: ,0,1.89452e+06,925946,925946,1.89452e+06
conditional probs:
	A  = 0.335852
	C  = 0.164148
	G  = 0.164148
	U  = 0.335852

fracLetsThru=0  (# nucs lets thru=0/total nucs=5.64092e+06

CPU time: 4.12u 0.03s 00:00:04.15 Elapsed: 00:00:04
