Params: ./cmzasha --no-stderr --learn-mm 0 @/projects/bio/zasha/seqs/embl_release76/hum.list 
Build: release
Host: gattaca.cs.washington.edu
pid: 30062
----cmFile: not-a-cm-file (global)
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum01.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum02.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum03.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum04.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum05.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum06.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum07.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum08.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum09.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum10.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum11.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum12.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum13.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum14.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum15.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum16.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum17.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum18.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum19.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum20.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum21.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum22.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum23.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum24.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum25.dat.fasta.gz
----fastaFile: /projects/bio/zasha/seqs/embl_release76/hum26.dat.fasta.gz

done 7.99988e+09 nucs (frac lets thru so far=0, 2d-fracLetsThru=0).
After scanning, learned Markov model:
0-order Markov model:
order & count-dump list: ,0,2.33471e+09,1.66548e+09,1.66548e+09,2.33422e+09
conditional probs:
	A  = 0.291843
	C  = 0.208188
	G  = 0.208188
	U  = 0.291782

done 7.99988e+09 nucs (frac lets thru so far=0, 2d-fracLetsThru=0).

CPU time: 2150.22u 26.83s 00:36:17.04 Elapsed: 00:35:49
